import { Component } from '@angular/core';

@Component({
  selector: 'app-blog',
  imports: [],
  templateUrl: './blog.html',
  styleUrls: ['./blog.scss']
})
export class BlogComponent {

}
